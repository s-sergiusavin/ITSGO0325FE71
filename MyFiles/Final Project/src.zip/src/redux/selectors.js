export const selectUser = (state) => state.auth;
export const selectPost = state => state.post;