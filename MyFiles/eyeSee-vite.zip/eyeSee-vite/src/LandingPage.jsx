import styles from "./styles/LandingPage.module.scss";
import logo from "./assets/LOGO.png";

function LandingPage() {
  return (
    <div className={styles.landingPage}>
      <img src={logo} alt="EyeSee Logo" className={styles.logo} />
      <h1 className={styles.title}>Welcome to EyeSee</h1>
      <p className={styles.subtitle}>Your new favorite social media app</p>
      <button className={styles.cta}>Get Started</button>
    </div>
  );
}

export default LandingPage;